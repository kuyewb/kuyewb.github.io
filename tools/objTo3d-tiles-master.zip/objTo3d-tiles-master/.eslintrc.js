module.exports = {
    "extends": "cesium/node",
    "globals": {
        "Promise": true
    }
};